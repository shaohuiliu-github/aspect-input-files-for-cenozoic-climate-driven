(part:user_manual:chap:cookbooks:sec:index)=
Cookbooks
======================

```{todo}
This section contains self contained cookbooks on how to design different geodynamic setups.

Examples of cookbooks could be how to setup a (more) realistic 2D or 3D subduction zone, how to use topography, how to use slab2 datasets, adding world fault databases, etc.
```

```{toctree}
:hidden:

```