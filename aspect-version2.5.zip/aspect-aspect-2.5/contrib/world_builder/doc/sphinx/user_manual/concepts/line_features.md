(part:user_manual:chap:concepts:sec:line_features)=
Line features
=============================

Line features are named after that they look like  line on a map, but these lines still represent 3D objects, like we saw in {ref}`part:user_manual:chap:concepts:sec:painting_the_world`, where we used the `subducting plate` feature.  An other example of a line feature is the `fault` feature. We will explain how these features work in practice in the {ref}`part:user_manual:chap:basic_starter_tutorial:sec:index`. 