(part:user_manual:chap:concepts:sec:point_features)=
Point features
=============================

Like with the other features, these features are named after what they look like on a map. The difference is that no such feature is currently implemented in the GWB. A potential point feature which could be implemented in the future is a plume or diapir feature.