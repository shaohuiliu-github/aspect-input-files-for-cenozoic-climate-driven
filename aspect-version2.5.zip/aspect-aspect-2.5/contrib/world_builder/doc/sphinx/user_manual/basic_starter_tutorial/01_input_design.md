(part:user_manual:chap:basic_starter_tutorial:sec:01_input_design)=
World Builder input file design
=====================================

GWB input files are plain text files using the JSON format. This means you can use any text editor to view and edit the files. If you are not familiar with the JSON format, it might be useful to familiarise yourself with it before continuing, although it is not necessary. The basic idea is that it allows data to be unambiguously structured to be readable by both humans and computers. 
