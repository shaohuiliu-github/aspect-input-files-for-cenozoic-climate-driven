(part:user_manual:chap:introduction:sec:issues)=
I found or have a GWB issue!
============================

Before diving into what the GWB can do, it is important to know what you should do when you run into a problem using the GWB. This can be anything from an warning or error, to strange output or a missing feature. The main place to go (after reading the relevant parts of this manual) is to [make an issue on GitHub](https://github.com/GeodynamicWorldBuilder/WorldBuilder/issues/new). 

There is also a [matrix room](https://matrix.to/#/!vhukRUGUINnZOIutoQ:matrix.org) which you can join.