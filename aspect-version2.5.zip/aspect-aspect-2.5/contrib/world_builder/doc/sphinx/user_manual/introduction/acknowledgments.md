(part:user_manual:chap:introduction:sec:acknowledgments)=
Developers, Contributors and Acknowledgments
===============

:::{include} ../../../../AUTHORS
::::

We also like to acknowledge funding support through NWO, CIG and NSF.