(part:user_manual:chap:introduction:sec:citing_the_world_builder)=
Citing the world builder
========================

:::::{tab-set}
:class: full-width

::::{tab-item} v0.5.0 Bibtex
:name: v0.5.0_bibtex

:::{include} ../../../../CITATION
::::

:::::