(part:API_manual:chap:API_FFI:sec:python_interface)=
Python interface
===========

```{todo}
Explain how to use the Python interface in your program. Point to or show the example in the example directory.
```