(part:API_manual:chap:API_FFI:sec:CPP_interface:subsec:ASPECT_integration)=
ASPECT integration
=================

```{todo}
Explain how the GWB is integrated into ASPECT
```