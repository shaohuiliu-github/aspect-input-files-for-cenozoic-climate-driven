(part:API_manual:chap:API_FFI:sec:CPP_interface:subsec:CPP_integration)=
C++ interface
=============

```{todo}
Explain how to use the CP interface in your program. Point to or show the example in the example directory.
```

```{toctree}
:hidden:

ASPECT_integration
```