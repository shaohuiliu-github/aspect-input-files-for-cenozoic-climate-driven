(part:API_manual:chap:API_FFI:sec:C_interface)=
C interface
===========

```{todo}
Explain how to use the C interface in your program. Point to or show the example in the example directory.
```