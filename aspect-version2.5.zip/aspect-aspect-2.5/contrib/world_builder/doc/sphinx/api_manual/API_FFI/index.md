(part:API_manual:chap:API_FFI:sec:index)=
API in different languages (FFI)
==========================================

```{todo}
Provide examples how to use the API in different programming languages.
```


```{toctree}
:hidden:

C_interface
CPP_interface/index
Fortran_interface
Python_interface
```
