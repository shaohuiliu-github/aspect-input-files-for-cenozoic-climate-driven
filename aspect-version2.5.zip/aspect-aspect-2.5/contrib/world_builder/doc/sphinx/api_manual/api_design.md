(part:API_manual:chap:API_design)=
API design
==========

```{todo}
Explain that the API works in a two (or three) phased process: World creation, world query and (depending on language) worl destruction. Also explain that the basic question the world query is asking, what is the temperature/composition/etc. at this location in the world.
```