(part:dev_manual:chap:contribute_to_code:sec:testing:subsec:integration_testers:subsubsec:app_testers)=
App tester
==========

```{todo}
Explain that this is the main form of integration testing in the GWB. If you want to write an integration test and you are in doubt, use this one.
```