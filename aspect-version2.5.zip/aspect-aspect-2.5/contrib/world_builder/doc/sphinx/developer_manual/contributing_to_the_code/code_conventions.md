(part:dev_manual:chap:contribute_to_code:sec:code_conventions)=
Code conventions
================

```{todo}
Explain why conventions are needed, and what conventions we use.
```