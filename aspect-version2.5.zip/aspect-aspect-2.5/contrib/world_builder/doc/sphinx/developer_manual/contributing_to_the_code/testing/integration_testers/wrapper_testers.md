(part:dev_manual:chap:contribute_to_code:sec:testing:subsec:integration_testers:subsubsec:wrapper_tester)=
Wrapper tester
==============

```{todo}
Explain these tests are used to test external interfaces to other programming languages.
```