(part:dev_manual:chap:contribute_to_code:sec:testing:subsec:integration_testers:subsubsec:visualization_tester)=
Visualization tester
====================

```{todo}
Explain that this is mostly used to test the visualalization app and for benchmarking
```