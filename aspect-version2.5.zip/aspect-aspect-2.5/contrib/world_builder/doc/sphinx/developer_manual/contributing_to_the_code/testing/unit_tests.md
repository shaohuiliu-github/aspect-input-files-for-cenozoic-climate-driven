(part:dev_manual:chap:contribute_to_code:sec:testing:subsec:unit_tests)=
Unit tests
==========

```{todo}
Explain what unit test are and for what they are useful. Refer to {doc}`/developer_manual/developing_for_the_GWB/index` for how to actually write them.
```