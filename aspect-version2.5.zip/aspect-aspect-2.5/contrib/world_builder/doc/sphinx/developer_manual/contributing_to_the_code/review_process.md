(part:dev_manual:chap:contribute_to_code:sec:review_process)=
Review process
==============

```{todo}
Explain the review process for code.
```