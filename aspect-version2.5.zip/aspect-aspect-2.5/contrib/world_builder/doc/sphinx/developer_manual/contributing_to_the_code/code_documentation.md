(part:dev_manual:chap:contribute_to_code:sec:code_doc_and_Doxygen)=
Code documentation and Doxygen
==============================

```{todo}
Explain the different ways to creating documetion inside the code, why it is important and how to view it in Doxyen.
```