(part:dev_manual:chap:contribute_to_code:sec:code_style_guide)=
Code Style Guide
================

```{todo}
Explain the preferred style for our C++14 code.
```