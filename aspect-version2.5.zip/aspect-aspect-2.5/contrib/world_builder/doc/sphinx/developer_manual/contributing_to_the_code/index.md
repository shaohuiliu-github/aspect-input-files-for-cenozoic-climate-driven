(part:dev_manual:chap:contribute_to_code:sec:index)=
Contributing to the code
=================================

```{todo}
Explain that keeping code readable, understanble, maintable and efficient is hard, and there will always be tradeoffs. But having conventions can help.
```

```{toctree}
:hidden:

code_documentation
code_conventions
code_style_guide
testing/index
tips_and_tricks
review_process
```