(part:dev_manual:chap:contribute_to_code:sec:testing:subsec:index)=
Testing your code
=================

```{todo} 
This section exlains why testing code is important, what kind of test there are, and in what case you should different cases. This section will focus on the concepts, not implementation. Implementation will be discussed in {doc}`/developer_manual/developing_for_the_GWB/index`.
```

```{toctree}
:caption: User manual
:hidden:

unit_tests
integration_testers/index
```