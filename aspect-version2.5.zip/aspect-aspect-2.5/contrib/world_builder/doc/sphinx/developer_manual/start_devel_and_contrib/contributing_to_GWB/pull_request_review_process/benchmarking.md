(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:pull_request_review:subsubsec:benchmarking)=
Benchmarking
============

```{todo}
Explain what is tested by the benchmarking tests (performance regressions), how it is tested and how to read the message in your pull request.
```