(part:dev_manual:chap:start_developing_and_contribute:sec:tools:subsec:index)=
required and recommended tools
============

```{todo}
Outline tools (and skills?) are needed and recommended
```

```{toctree}
:hidden:

git
astyle
IDE
```