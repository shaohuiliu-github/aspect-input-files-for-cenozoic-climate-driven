(part:dev_manual:chap:start_developing_and_contribute:sec:tools:subsec:git)=
Git
===


```{todo}
Explain what git is, why it is important, (very) basic usage, and how to find more info on it.
```