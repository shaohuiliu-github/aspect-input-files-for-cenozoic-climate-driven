(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:helping_others)=
Helping others
==============

```{todo}
Explain how you can help others and the code of conduct (or should that go somewhere else?)
```