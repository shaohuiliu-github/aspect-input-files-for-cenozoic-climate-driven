(part:dev_manual:chap:start_developing_and_contribute:sec:index)=
How to start developing and contributing
=======================================

```{todo}
Outline what a developers needs to know when developing and (hopefully contributing).
```

```{toctree}
:hidden:

tools/index
contributing_to_GWB/index
```
