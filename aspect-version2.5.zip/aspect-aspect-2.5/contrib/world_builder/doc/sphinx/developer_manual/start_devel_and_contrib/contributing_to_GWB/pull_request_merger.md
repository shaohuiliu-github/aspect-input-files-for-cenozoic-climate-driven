(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:pull_request_merging)=
Pull request merging
====================

```{todo}
Explain how decisions are made about whether a pull request are merged.
```