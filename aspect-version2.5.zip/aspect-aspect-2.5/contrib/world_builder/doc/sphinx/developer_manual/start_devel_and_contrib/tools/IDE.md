(part:dev_manual:chap:start_developing_and_contribute:sec:tools:subsec:IDE)=
IDE
===


```{todo}
Explain what and IDE is, why it is important, (very) basic usage for some common IDE's, and how to find more info on it.
```