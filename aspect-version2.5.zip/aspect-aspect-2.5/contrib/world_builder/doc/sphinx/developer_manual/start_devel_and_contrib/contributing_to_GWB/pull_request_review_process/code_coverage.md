(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:pull_request_review:subsubsec:code_coverage)=
Code coverage
=======

```{todo}
Explain what code coverage is, how it works in practice, when it is important and how to fix it if needed
```