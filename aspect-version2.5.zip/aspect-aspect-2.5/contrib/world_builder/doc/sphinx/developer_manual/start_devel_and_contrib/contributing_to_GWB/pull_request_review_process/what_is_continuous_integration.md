(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:pull_request_review:subsubsec:CI)=
What is continuous integration?
===============================

```{todo}
Explain what contious integration (CI) is and why we do it: merging a pull request should never break the code in the main branch.
```