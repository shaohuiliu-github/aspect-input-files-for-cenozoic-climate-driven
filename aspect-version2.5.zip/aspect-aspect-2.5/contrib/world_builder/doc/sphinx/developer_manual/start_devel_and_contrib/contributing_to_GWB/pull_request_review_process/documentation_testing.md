(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:pull_request_review:subsubsec:doc_testing)=
Documentation testing
=====================

```{todo}
Explain that the documentation is build for every pull request (which can fail), and how to view the result.
```