(part:dev_manual:chap:start_developing_and_contribute:sec:contributing_to_gwb:subsec:making_a_pull_request)=
Making a pull request
=====================

```{todo}
Explain the process of making a pull request
```