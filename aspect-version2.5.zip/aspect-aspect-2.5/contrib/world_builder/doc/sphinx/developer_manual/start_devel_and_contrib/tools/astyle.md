(part:dev_manual:chap:start_developing_and_contribute:sec:tools:subsec:astyle)=
Astyle
=====

```{todo}
Explain what Astyle does, why it is important and how to get the right version.
```