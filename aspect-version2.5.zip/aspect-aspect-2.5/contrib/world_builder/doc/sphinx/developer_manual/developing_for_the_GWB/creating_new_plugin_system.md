(part:dev_manual:chap:developing_for_the_GWB:sec:creating_new_plugin_systems)=
Creating new plugin system
==========================

```{todo}
Explain that this is very advanced, and you should contact the developers, but also explain how to do it.
```