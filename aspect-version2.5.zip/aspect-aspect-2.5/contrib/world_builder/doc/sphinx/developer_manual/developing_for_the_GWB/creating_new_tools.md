(part:dev_manual:chap:developing_for_the_GWB:sec:creating_new_tools)=
Creating new tools
==================

```{todo}
Explains where tools live in the repository, how they each work internally and how you can make (and contribute) your own.
```