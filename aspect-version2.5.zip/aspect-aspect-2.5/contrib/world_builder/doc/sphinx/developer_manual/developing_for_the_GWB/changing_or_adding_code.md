(part:dev_manual:chap:developing_for_the_GWB:sec:changes_or_adding_code)=
Changing or adding code
=======================

```{todo}
Explain how to change code in the core. Not sure if this section is needed.
```