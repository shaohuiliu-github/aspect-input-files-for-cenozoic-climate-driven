(part:dev_manual:chap:developing_for_the_GWB:sec:creating_new_plugins)=
Creating new plugins
====================

```{todo}
Explain how to create a new plugin. If possible find one which already nearly does what you want and copy and change it, but also explain how to build one from sratch.
```