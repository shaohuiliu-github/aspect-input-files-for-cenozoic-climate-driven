(part:dev_manual:chap:developing_for_the_GWB:sec:index)=
Developing for the GWB
======================

```{todo} 
Explain that there are four cases: adding a plugin, adding a new plugin system, changing or adding to the code or adding a new tool. We will start with the code structure.
```

```{toctree}
:caption: User manual
:hidden:

code_structure
creating_new_plugins
changing_or_adding_code
creating_new_plugin_system
creating_new_tools
```
