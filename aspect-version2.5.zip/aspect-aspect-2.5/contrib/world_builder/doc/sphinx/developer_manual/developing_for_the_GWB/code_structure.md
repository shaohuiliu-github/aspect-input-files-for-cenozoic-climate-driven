(part:dev_manual:chap:developing_for_the_GWB:sec:code_structure)=
Code structure
==============

```{todo}
Go through how the code is actually structured with directories and from core to utilities and pugins.
```