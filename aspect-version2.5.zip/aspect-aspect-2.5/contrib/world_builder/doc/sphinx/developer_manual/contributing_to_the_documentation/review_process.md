(part:dev_manual:chap:contribute_to_doc:sec:review_process)=
The review process
================

```{todo}
Explain that documentation goes to the exact same review process as code.
```