(part:dev_manual:chap:contribute_to_doc:sec:doc_style_guide)=
Documentation style guide
=========================

```{todo}
Explain how to style the markdown files correctly
```