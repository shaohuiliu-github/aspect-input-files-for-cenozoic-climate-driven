(part:dev_manual:chap:contribute_to_doc:sec:doc_testing)=
Documentation testing
=====================

```{todo}
Explain how the documentation is tested in each pull request. It is build and (todo) all the world builder input files are run (checking for errors, not comparing output).
```