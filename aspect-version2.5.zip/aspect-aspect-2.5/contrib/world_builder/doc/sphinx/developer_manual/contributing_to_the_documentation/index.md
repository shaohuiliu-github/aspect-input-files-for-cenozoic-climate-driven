(part:dev_manual:chap:contribute_to_doc:sec:index)=
Contributing to the documentation
=================================

```{todo}
The documentation is very important and it is also a good way to learn git and the review process. Show that there is a button on each documentation page where you can suggest edits!
```

```{toctree}
:hidden:

important_syntax
documentation_style_guide
documentation_testing
tips_and_tricks
review_process
```