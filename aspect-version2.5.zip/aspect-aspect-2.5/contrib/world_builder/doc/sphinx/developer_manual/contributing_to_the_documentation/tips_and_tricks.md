(part:dev_manual:chap:contribute_to_doc:sec:tips_and_tricks)=
Tips and tricks
================

```{todo}
Explain how to make useful, easy to read and good looking documentation.
```