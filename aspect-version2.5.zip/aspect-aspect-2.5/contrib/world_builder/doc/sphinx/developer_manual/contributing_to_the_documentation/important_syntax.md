(part:dev_manual:chap:contribute_to_doc:sec:important_syntax)=
Important syntax
===============

```{todo}
Explain that the style is MyST and what the most important commands are
```