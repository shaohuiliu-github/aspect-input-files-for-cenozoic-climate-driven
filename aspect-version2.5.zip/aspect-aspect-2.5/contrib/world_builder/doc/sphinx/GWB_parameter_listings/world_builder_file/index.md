
(part:GWB_parameter_listings:chap:world_builder_file:sec:index)=
The World Builder file
======================


```{todo}
:class: full-width
Explain how to use this page. Here is an example how to link to a specific item in the all open tab:
[link](open_features_items_oneOf_5_coordinates_items_items).
```

:::::{tab-set}
:class: full-width

::::{tab-item} All open
:name: all_open

:::{include} ../../../../tests/gwb-dat/world_builder_declarations_open.md
::::

::::{tab-item} Only root open
:name: root_open

:::{include} ../../../../tests/gwb-dat/world_builder_declarations_closed.md
::::

:::::
