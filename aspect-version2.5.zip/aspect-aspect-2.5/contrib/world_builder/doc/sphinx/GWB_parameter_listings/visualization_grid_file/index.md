(part:GWB_parameter_listings:chap:visualization_grid_file:sec:index)=
Visualization Grid file
=======================

```{todo}
This part of the manual is used to list all the parameters for the visualization grid file.
```
